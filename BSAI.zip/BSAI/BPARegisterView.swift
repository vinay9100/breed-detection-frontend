import SwiftUI

struct BPARegisterView: View {
    @Binding var path: [AppRoute]
    @State private var fullName = ""
    @State private var officerId = ""
    @State private var department = ""
    @State private var email = ""
    @State private var phoneNumber = ""
    @State private var password = ""
    @State private var appeared = false
    
    var body: some View {
        ZStack {
            Color(hex: "F8FBF9").ignoresSafeArea()
            
            VStack(spacing: 0) {
                navigationHeader
                
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 24) {
                        logoSection
                        
                        VStack(spacing: 8) {
                            Text("Register as BPA Officer")
                                .font(.system(size: 28, weight: .bold))
                                .foregroundColor(Color(hex: "1B5E20"))
                            Text("Create your government authority account")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                        }
                        
                        VStack(spacing: 16) {
                            inputField(label: "Full Name *", icon: "person", placeholder: "John Smith", text: $fullName)
                            inputField(label: "Officer ID *", icon: "person.text.rectangle", placeholder: "BPA-2024-XXXX", text: $officerId)
                            inputField(label: "Department *", icon: "building.columns", placeholder: "Department Name", text: $department)
                            inputField(label: "Email Address *", icon: "envelope", placeholder: "officer@bpa.gov", text: $email)
                            inputField(label: "Phone Number *", icon: "phone", placeholder: "+91 XXXXXXXXXX", text: $phoneNumber)
                            passwordField
                        }
                        
                        registerButton
                        
                        loginLink
                        
                        Spacer(minLength: 40)
                    }
                    .padding(.horizontal, 24)
                }
            }
        }
        .onAppear {
            appeared = true
        }
    }
    
    private var navigationHeader: some View {
        HStack {
            Button(action: {
                if !path.isEmpty {
                    _ = path.removeLast()
                }
            }) {
                Image(systemName: "arrow.left")
                    .font(.title3.bold())
                    .foregroundColor(.primary)
            }
            Spacer()
        }
        .padding()
    }
    
    private var logoSection: some View {
        ZStack {
            Circle()
                .fill(Color(hex: "00C853").opacity(0.1))
                .frame(width: 80, height: 80)
            
            Circle()
                .fill(LinearGradient(colors: [Color(hex: "00C853"), Color(hex: "00A843")], startPoint: .topLeading, endPoint: .bottomTrailing))
                .frame(width: 60, height: 60)
            
            Image(systemName: "shield.checkered")
                .font(.system(size: 28))
                .foregroundColor(.white)
        }
        .scaleEffect(appeared ? 1 : 0.8)
        .opacity(appeared ? 1 : 0)
        .animation(.spring(response: 0.6, dampingFraction: 0.7).delay(0.1), value: appeared)
    }
    
    private func inputField(label: String, icon: String, placeholder: String, text: Binding<String>) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(label)
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(.primary.opacity(0.8))
            
            HStack(spacing: 12) {
                Image(systemName: icon)
                    .foregroundColor(.secondary)
                    .frame(width: 20)
                
                TextField(placeholder, text: text)
                    .font(.system(size: 16))
            }
            .padding()
            .background(Color.white)
            .cornerRadius(12)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(Color.gray.opacity(0.2), lineWidth: 1)
            )
        }
    }
    
    private var passwordField: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Password *")
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(.primary.opacity(0.8))
            
            HStack(spacing: 12) {
                Image(systemName: "lock")
                    .foregroundColor(.secondary)
                    .frame(width: 20)
                
                SecureField("Create a strong password", text: $password)
                    .font(.system(size: 16))
                
                Image(systemName: "eye")
                    .foregroundColor(.secondary)
            }
            .padding()
            .background(Color.white)
            .cornerRadius(12)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(Color.gray.opacity(0.2), lineWidth: 1)
            )
        }
    }
    
    private var registerButton: some View {
        Button(action: {
            // Success registration simulation
            if !path.isEmpty {
                _ = path.removeLast()
            }
        }) {
            Text("Register as Officer")
                .font(.headline)
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 18)
                .background(Color(hex: "008D43"))
                .cornerRadius(14)
                .shadow(color: Color(hex: "008D43").opacity(0.3), radius: 10, x: 0, y: 5)
        }
        .buttonStyle(PressScaleButtonStyle())
        .padding(.top, 10)
    }
    
    private var loginLink: some View {
        HStack(spacing: 4) {
            Text("Already have an account?")
                .foregroundColor(.secondary)
            Button(action: {
                if !path.isEmpty {
                    _ = path.removeLast()
                }
            }) {
                Text("Sign In")
                    .fontWeight(.bold)
                    .foregroundColor(Color(hex: "00C853"))
            }
        }
        .font(.system(size: 14))
        .padding(.top, 10)
    }
}

#Preview {
    BPARegisterView(path: .constant([]))
}
