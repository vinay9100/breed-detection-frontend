import SwiftUI

struct CameraView: View {
    @Binding var path: [AppRoute]
    @State private var selectedMode = "Front View"
    @State private var appeared = false
    
    let modes = ["Front View", "Side Profile", "Full Body"]
    
    var body: some View {
        ZStack {
            // Camera Background (Dark Blue/Gray)
            Color(red: 10/255, green: 20/255, blue: 30/255)
                .ignoresSafeArea()
            
            // Simulation of Camera View
            VStack {
                Spacer()
                VStack(spacing: 15) {
                    Image(systemName: "camera")
                        .font(.system(size: 60))
                        .foregroundColor(.gray.opacity(0.3))
                    Text("Camera View")
                        .font(.headline)
                        .foregroundColor(.gray.opacity(0.3))
                }
                Spacer()
            }
            
            // Top Controls
            VStack {
                HStack {
                    Button(action: {
                        if !path.isEmpty {
                            _ = path.removeLast()
                        }
                    }) {
                        Image(systemName: "xmark")
                            .font(.title3)
                            .foregroundColor(.white)
                            .padding(12)
                            .background(Color.black.opacity(0.4))
                            .clipShape(Circle())
                    }
                    
                    Spacer()
                    
                    HStack(spacing: 5) {
                        Image(systemName: "bolt.fill")
                        Text("Front View")
                            .font(.subheadline.bold())
                    }
                    .foregroundColor(.white)
                    .padding(.horizontal, 15)
                    .padding(.vertical, 10)
                    .background(Color.green)
                    .cornerRadius(25)
                    
                    Spacer()
                    
                    Button(action: {
                        // Flash or settings
                    }) {
                        Image(systemName: "arrow.triangle.2.circlepath")
                            .font(.title3)
                            .foregroundColor(.white)
                            .padding(12)
                            .background(Color.black.opacity(0.4))
                            .clipShape(Circle())
                    }
                }
                .padding()
                
                Spacer()
                
                // Overlay Message
                VStack(spacing: 8) {
                    Text("Position the animal within the frame")
                        .font(.headline)
                        .foregroundColor(.white)
                    Text("Ensure good lighting and steady position")
                        .font(.subheadline)
                        .foregroundColor(.green)
                }
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color.black.opacity(0.7))
                .cornerRadius(15)
                .padding(.horizontal, 25)
                .padding(.bottom, 20)
                
                // Bottom Controls
                VStack(spacing: 25) {
                    // Shutter Button
                    Button(action: {
                        path.append(.aiProcessing)
                    }) {
                        ZStack {
                            Circle()
                                .stroke(Color.white, lineWidth: 4)
                                .frame(width: 80, height: 80)
                            Circle()
                                .fill(Color.green)
                                .frame(width: 65, height: 65)
                        }
                    }
                    
                    // Mode Picker
                    HStack(spacing: 10) {
                        ForEach(modes, id: \.self) { mode in
                            Button(action: {
                                withAnimation(.spring()) {
                                    selectedMode = mode
                                }
                            }) {
                                Text(mode)
                                    .font(.system(size: 14, weight: selectedMode == mode ? .semibold : .regular))
                                    .foregroundColor(selectedMode == mode ? .white : .gray)
                                    .padding(.horizontal, 15)
                                    .padding(.vertical, 10)
                                    .background(selectedMode == mode ? Color.white.opacity(0.15) : Color.clear)
                                    .cornerRadius(20)
                            }
                        }
                    }
                    .padding(.bottom, 20)
                }
                .frame(maxWidth: .infinity)
                .background(Color(red: 10/255, green: 20/255, blue: 30/255))
            }
        }
        .onAppear {
            appeared = true
        }
    }
}
