import SwiftUI

struct HomeView: View {
    @Binding var path: [AppRoute]
    @State private var appeared = false

    var body: some View {
        ZStack {
            Color(hex: "F9FBF9").ignoresSafeArea()
            
            VStack(spacing: 0) {
                headerSection
                
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 30) {
                        statsRow
                            .opacity(appeared ? 1 : 0)
                            .offset(y: appeared ? 0 : 20)
                            .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.3), value: appeared)
                        
                        alertsSection
                            .opacity(appeared ? 1 : 0)
                            .offset(y: appeared ? 0 : 20)
                            .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.4), value: appeared)
                        
                        bottomActionsGrid
                            .opacity(appeared ? 1 : 0)
                            .offset(y: appeared ? 0 : 20)
                            .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.5), value: appeared)
                        
                    }
                    .padding(.top, 15) // Natural spacing instead of overlapping
                    .padding(.bottom, 30)
                }
            }
        }
        .onAppear {
            withAnimation {
                appeared = true
            }
        }
    }
    
    // MARK: - Subviews
    
    private var headerSection: some View {
        VStack(spacing: 0) {
            VStack(alignment: .leading, spacing: 16) {
                // Top Row: Centered Greeting and Logout
                ZStack {
                    // Centered Greeting
                    let greetingText = GreetingHelper.getGreeting(for: "Farmer")
                    Text("\(greetingText) 👋")
                        .font(.system(size: 24, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                        .lineLimit(1)
                        .minimumScaleFactor(0.8)
                    
                    // Top-Right Logout Button
                    HStack {
                        Spacer()
                        Button(action: {
                            path.removeAll() // Pop to root (Login)
                        }) {
                            Image(systemName: "rectangle.portrait.and.arrow.right")
                                .font(.system(size: 20, weight: .bold)) // Slightly increased size to balance
                                .foregroundColor(.white)
                                .padding(8) // Reduced padding for better proportions
                                .background(Color.white.opacity(0.2))
                                .clipShape(Circle())
                        }
                    }
                }
                .padding(.horizontal, 24)
                .padding(.top, 5) // Perfect gap under the camera notch
                .opacity(appeared ? 1 : 0)
                .offset(y: appeared ? 0 : -20)
                .animation(.easeOut(duration: 0.6).delay(0.1), value: appeared)
                
                // Left aligned subtitle
                Text("Ready to scan your livestock?")
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(.white.opacity(0.85))
                    .padding(.horizontal, 24)
                    .opacity(appeared ? 1 : 0)
                    .offset(y: appeared ? 0 : -20)
                    .animation(.easeOut(duration: 0.6).delay(0.15), value: appeared)
                
                scanAnimalCard
                    .padding(.horizontal, 24)
                    .scaleEffect(appeared ? 1 : 0.9)
                    .opacity(appeared ? 1 : 0)
                    .animation(.spring(response: 0.7, dampingFraction: 0.6).delay(0.2), value: appeared)
            }
            .padding(.bottom, 25) // reduced to prevent overlap
            .frame(maxWidth: .infinity)
            .background(
                ZStack {
                    Color(hex: "00A661")
                    
                    // Decorative patterns for header
                    Circle()
                        .fill(Color.white.opacity(0.05))
                        .frame(width: 150, height: 150)
                        .offset(x: -100, y: -20)
                    
                    Circle()
                        .fill(Color.white.opacity(0.08))
                        .frame(width: 100, height: 100)
                        .offset(x: 160, y: 10)
                }
                .clipShape(RoundedCorner(radius: 30, corners: [.bottomLeft, .bottomRight]))
                .shadow(color: Color(hex: "00A661").opacity(0.15), radius: 20, x: 0, y: 15)
                .ignoresSafeArea(edges: .top)
            )
        }
    }
    
    private var scanAnimalCard: some View {
        Button(action: {
            withAnimation(.spring(response: 0.5, dampingFraction: 0.7)) {
                path.append(.scanGuide)
            }
        }) {
            HStack(spacing: 18) {
                ZStack {
                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                        .fill(Color(hex: "00A661").opacity(0.08))
                        .frame(width: 68, height: 68)
                    
                    Image(systemName: "viewfinder")
                        .font(.system(size: 32, weight: .bold))
                        .foregroundColor(Color(hex: "00A661"))
                }
                
                VStack(alignment: .leading, spacing: 6) {
                    Text("Scan Animal")
                        .font(.system(size: 20, weight: .bold, design: .rounded))
                        .foregroundColor(.primary)
                    Text("AI-powered breed detection")
                        .font(.system(size: 14))
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                ZStack {
                    Circle()
                        .fill(LinearGradient(colors: [Color(hex: "00A661"), Color(hex: "008D43")], startPoint: .topLeading, endPoint: .bottomTrailing))
                        .frame(width: 48, height: 48)
                    
                    Image(systemName: "sparkles")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.white)
                }
                .shadow(color: Color(hex: "00A661").opacity(0.3), radius: 8, x: 0, y: 4)
            }
            .padding(20)
            .background(
                RoundedRectangle(cornerRadius: 32, style: .continuous)
                    .fill(Color.white)
                    .shadow(color: Color.black.opacity(0.06), radius: 25, x: 0, y: 12)
            )
        }
        .buttonStyle(EnhancedRoleButtonStyle())
    }
    
    private var statsRow: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 16) {
                StatsCard(icon: "viewfinder", value: "24", label: "Total Scans", color: Color(hex: "00A661")) {
                    path.append(.scanHistory)
                }
                StatsCard(icon: "waveform.path", value: "96.8%", label: "Avg. Confidence", color: .blue) {
                    path.append(.analyticsHub)
                }
                StatsCard(icon: "chart.line.uptrend.xyaxis", value: "12", label: "Herd Size", color: .purple) {
                    path.append(.herdSummary)
                }
            }
            .padding(.horizontal, 24)
            .padding(.vertical, 5)
        }
    }
    
    private var alertsSection: some View {
        VStack(spacing: 12) {
            Button(action: {
                path.append(.vaccinationPlanner)
            }) {
                AlertRow(icon: "exclamationmark.circle.fill", message: "Vaccination due for 3 animals", color: .orange)
            }
            
            Button(action: {
                path.append(.seasonalCare)
            }) {
                AlertRow(icon: "exclamationmark.circle.fill", message: "Heat stress alert for tomorrow", color: .orange)
            }
        }
        .padding(.horizontal, 24)
    }
    
    private var bottomActionsGrid: some View {
        HStack(spacing: 16) {
            QuickActionSmallCard(icon: "waveform.path", title: "Compare Breeds", color: .blue) {
                path.append(.breedComparison)
            }
            
            QuickActionSmallCard(icon: "chart.line.uptrend.xyaxis", title: "Predict Yield", color: .purple) {
                path.append(.yieldPrediction)
            }
        }
        .padding(.horizontal, 24)
    }
}

struct QuickActionSmallCard: View {
    let icon: String
    let title: String
    let color: Color
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 15) {
                ZStack {
                    RoundedRectangle(cornerRadius: 15)
                        .fill(color.opacity(0.1))
                        .frame(width: 56, height: 56)
                    Image(systemName: icon)
                        .font(.system(size: 24))
                        .foregroundColor(color)
                }
                
                Text(title)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(.primary)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 25)
            .background(Color.white)
            .cornerRadius(24)
            .shadow(color: Color.black.opacity(0.04), radius: 10, x: 0, y: 5)
        }
        .buttonStyle(ScaleButtonStyle())
    }
}


// Reusable helper for time-based greetings
struct GreetingHelper {
    static func getGreeting(for name: String) -> String {
        let hour = Calendar.current.component(.hour, from: Date())
        var timeGreeting = ""
        
        if hour < 12 {
            timeGreeting = "Good Morning"
        } else if hour < 17 {
            timeGreeting = "Good Afternoon"
        } else {
            timeGreeting = "Good Evening"
        }
        
        return "\(timeGreeting), \(name)"
    }
}

#Preview {
    HomeView(path: .constant([]))
}
