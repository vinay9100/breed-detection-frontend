import SwiftUI

// MARK: - App Entry Point
// Single NavigationStack with path-based navigation.
// Every screen is pushed onto `path`; resetting `path = []` returns to root (SplashView/LoginView).

@main
struct BreedSureAIApp: App {
    var body: some Scene {
        WindowGroup {
            AppRootView()
        }
    }
}
