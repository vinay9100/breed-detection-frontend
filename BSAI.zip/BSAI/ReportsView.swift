import SwiftUI

struct ReportsView: View {
    @Binding var path: [AppRoute]
    @State private var appeared = false
    
    var body: some View {
        VStack(spacing: 0) {
            header
            
            ScrollView(showsIndicators: false) {
                VStack(spacing: 25) {
                    latestAnalysisCard
                    pastReportsSection
                    
                    Spacer(minLength: 100)
                }
            }
        }
        .background(Color(hex: "F8FBF9").ignoresSafeArea())
    }
    
    // MARK: - Subviews
    
    private var header: some View {
        HStack {
            Text("Reports")
                .font(.largeTitle.bold())
            Spacer()
            Button(action: {}) {
                Image(systemName: "line.3.horizontal.decrease.circle")
                    .font(.title2)
                    .foregroundColor(.green)
            }
        }
        .padding(.horizontal, 24)
        .padding(.top, 20)
    }
    
    private var latestAnalysisCard: some View {
        Button(action: {
            path.append(.reportPreview)
        }) {
            HStack {
                VStack(alignment: .leading, spacing: 5) {
                    Text("Latest Analysis")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(.white.opacity(0.8))
                    Text("February 2026 Report")
                        .font(.title2.bold())
                        .foregroundColor(.white)
                }
                Spacer()
                Image(systemName: "chevron.right.circle.fill")
                    .font(.system(size: 40))
                    .foregroundColor(.white)
            }
            .padding(24)
            .background(
                LinearGradient(colors: [.green, Color(hex: "1B5E20")], startPoint: .topLeading, endPoint: .bottomTrailing)
            )
            .cornerRadius(25)
            .shadow(color: Color.green.opacity(0.3), radius: 15, x: 0, y: 8)
        }
        .buttonStyle(ScaleButtonStyle())
        .padding(.horizontal, 24)
        .padding(.top, 20)
    }
    
    private var pastReportsSection: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("Past Reports")
                .font(.headline)
                .padding(.horizontal, 24)
            
            VStack(spacing: 14) {
                ReportHistoryRow(title: "January 2026", date: "Feb 01, 2026", type: "Monthly")
                ReportHistoryRow(title: "Year End 2025", date: "Jan 05, 2026", type: "Annual")
                ReportHistoryRow(title: "December 2025", date: "Jan 01, 2026", type: "Monthly")
                ReportHistoryRow(title: "November 2025", date: "Dec 01, 2025", type: "Monthly")
            }
            .padding(.horizontal, 24)
        }
    }
}

struct ReportHistoryRow: View {
    let title: String
    let date: String
    let type: String
    
    var body: some View {
        HStack(spacing: 15) {
            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.gray.opacity(0.1))
                    .frame(width: 48, height: 48)
                Image(systemName: "doc.text")
                    .foregroundColor(.gray)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.headline)
                Text(date)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            Text(type)
                .font(.system(size: 10, weight: .bold))
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(Color.gray.opacity(0.1))
                .foregroundColor(.secondary)
                .cornerRadius(6)
            
            Image(systemName: "chevron.right")
                .font(.system(size: 12, weight: .bold))
                .foregroundColor(.gray.opacity(0.3))
        }
        .padding(16)
        .background(Color.white)
        .cornerRadius(18)
        .shadow(color: Color.black.opacity(0.02), radius: 5, x: 0, y: 2)
    }
}

#Preview {
    ReportsView(path: .constant([]))
}
