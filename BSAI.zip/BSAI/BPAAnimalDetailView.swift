import SwiftUI

struct BPAAnimalDetailView: View {
    @Binding var path: [AppRoute]
    @State private var appeared = false
    
    var body: some View {
        ZStack {
            Color(hex: "F8FBF9").ignoresSafeArea()
            
            VStack(spacing: 0) {
                headerSection
                
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 25) {
                        animalHeroCard
                        
                        ownerInfoSection
                        
                        breedHistoryTimeline
                        
                        Spacer(minLength: 40)
                    }
                    .padding(24)
                    .padding(.top, -30)
                }
            }
        }
        .onAppear {
            withAnimation(.easeOut(duration: 0.6)) {
                appeared = true
            }
        }
    }
    
    private var headerSection: some View {
        VStack(spacing: 15) {
            HStack {
                Button(action: {
                    if !path.isEmpty {
                        _ = path.removeLast()
                    }
                }) {
                    Image(systemName: "arrow.left")
                        .font(.title3.bold())
                        .foregroundColor(.white)
                        .padding(12)
                        .background(Color.white.opacity(0.15))
                        .clipShape(Circle())
                }
                
                Text("Animal Profile")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.leading, 10)
                
                Spacer()
                
                Button(action: {}) {
                    Image(systemName: "pencil")
                        .font(.system(size: 18))
                        .foregroundColor(.white)
                        .padding(12)
                        .background(Color.white.opacity(0.15))
                        .clipShape(Circle())
                }
            }
            .padding(.horizontal, 24)
            .padding(.top, 20)
            .padding(.bottom, 25)
        }
        .background(
            LinearGradient(
                colors: [Color(hex: "00C853"), Color(hex: "008D43")],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
        )
    }
    
    private var animalHeroCard: some View {
        VStack(spacing: 20) {
            HStack(spacing: 20) {
                ZStack {
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color.gray.opacity(0.1))
                        .frame(width: 100, height: 100)
                    Image(systemName: "pawprint.fill")
                        .font(.system(size: 40))
                        .foregroundColor(Color(hex: "00C853"))
                }
                
                VStack(alignment: .leading, spacing: 5) {
                    Text("Holstein Friesian")
                        .font(.system(size: 22, weight: .bold))
                        .foregroundColor(Color(hex: "1B5E20"))
                    
                    HStack(spacing: 8) {
                        Text("ET-2024-8472")
                            .font(.system(size: 14, weight: .semibold))
                            .padding(.horizontal, 10)
                            .padding(.vertical, 4)
                            .background(Color(hex: "00C853").opacity(0.1))
                            .foregroundColor(Color(hex: "00C853"))
                            .cornerRadius(8)
                        
                        Text("Verified")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(.blue)
                    }
                }
                Spacer()
            }
            
            Divider()
            
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())], spacing: 20) {
                ProfileStat(label: "Species", value: "Cattle")
                ProfileStat(label: "Sex", value: "Female")
                ProfileStat(label: "Age", value: "4.5 Years")
                ProfileStat(label: "Health", value: "Excellent")
                ProfileStat(label: "Yield", value: "24L/Day")
                ProfileStat(label: "Weight", value: "580 Kg")
            }
        }
        .padding(24)
        .background(Color.white)
        .cornerRadius(24)
        .shadow(color: Color.black.opacity(0.04), radius: 15, x: 0, y: 10)
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 20)
    }
    
    private var ownerInfoSection: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                Image(systemName: "person.circle.fill")
                    .foregroundColor(.blue)
                Text("Owner Information")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(Color(hex: "1B5E20"))
                Spacer()
            }
            
            VStack(spacing: 15) {
                HStack(spacing: 15) {
                    Circle()
                        .fill(Color.blue.opacity(0.1))
                        .frame(width: 44, height: 44)
                        .overlay(Text("RK").font(.system(size: 16, weight: .bold)).foregroundColor(.blue))
                    
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Ramesh Kumar")
                            .font(.system(size: 16, weight: .bold))
                        Text("Village Karnal, Haryana")
                            .font(.system(size: 13))
                            .foregroundColor(.secondary)
                    }
                    Spacer()
                    
                    Button(action: {}) {
                        Image(systemName: "phone.fill")
                            .foregroundColor(.white)
                            .padding(10)
                            .background(Color.blue)
                            .clipShape(Circle())
                    }
                }
                
                Divider()
                
                HStack {
                    OwnerDetailItem(label: "Total Animals", value: "12")
                    Spacer()
                    OwnerDetailItem(label: "Member Since", value: "Aug 2022")
                    Spacer()
                    OwnerDetailItem(label: "BPA ID", value: "OFF-8472")
                }
            }
        }
        .padding(24)
        .background(Color.white)
        .cornerRadius(24)
        .shadow(color: Color.black.opacity(0.04), radius: 15, x: 0, y: 10)
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 20)
        .animation(.spring().delay(0.1), value: appeared)
    }
    
    private var breedHistoryTimeline: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                Image(systemName: "history")
                    .foregroundColor(.purple)
                Text("Breed Detection History")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(Color(hex: "1B5E20"))
                Spacer()
            }
            
            VStack(spacing: 0) {
                TimelineItem(date: "Feb 13, 2026", title: "Latest AI Verification", subtitle: "98.5% Confidence - Holstein Friesian", icon: "sparkles", color: .purple, isFirst: true)
                TimelineItem(date: "Jan 05, 2026", title: "Routine Inspection", subtitle: "No changes detected", icon: "checkmark.shield", color: .green)
                TimelineItem(date: "Aug 12, 2025", title: "Initial Registration", subtitle: "Verified as Holstein Friesian Calf", icon: "plus.circle", color: .blue, isLast: true)
            }
        }
        .padding(24)
        .background(Color.white)
        .cornerRadius(24)
        .shadow(color: Color.black.opacity(0.04), radius: 15, x: 0, y: 10)
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 20)
        .animation(.spring().delay(0.2), value: appeared)
    }
}

struct ProfileStat: View {
    let label: String
    let value: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(label)
                .font(.system(size: 11))
                .foregroundColor(.secondary)
            Text(value)
                .font(.system(size: 14, weight: .bold))
                .foregroundColor(Color(hex: "1B5E20"))
        }
    }
}

struct OwnerDetailItem: View {
    let label: String
    let value: String
    
    var body: some View {
        VStack(spacing: 4) {
            Text(label)
                .font(.system(size: 11))
                .foregroundColor(.secondary)
            Text(value)
                .font(.system(size: 14, weight: .bold))
        }
    }
}

struct TimelineItem: View {
    let date: String
    let title: String
    let subtitle: String
    let icon: String
    let color: Color
    var isFirst: Bool = false
    var isLast: Bool = false
    
    var body: some View {
        HStack(alignment: .top, spacing: 20) {
            VStack(spacing: 0) {
                Circle()
                    .fill(color)
                    .frame(width: 12, height: 12)
                    .background(Circle().stroke(color.opacity(0.2), lineWidth: 4))
                
                if !isLast {
                    Rectangle()
                        .fill(color.opacity(0.2))
                        .frame(width: 2)
                        .frame(maxHeight: .infinity)
                }
            }
            .padding(.top, 4)
            
            VStack(alignment: .leading, spacing: 6) {
                Text(date)
                    .font(.system(size: 12, weight: .bold))
                    .foregroundColor(.secondary)
                
                Text(title)
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(Color(hex: "1B5E20"))
                
                Text(subtitle)
                    .font(.system(size: 13))
                    .foregroundColor(.secondary)
                    .padding(.bottom, isLast ? 0 : 25)
            }
            
            Spacer()
        }
    }
}

#Preview {
    BPAAnimalDetailView(path: .constant([]))
}
