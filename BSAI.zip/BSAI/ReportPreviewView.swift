import SwiftUI

struct ReportPreviewView: View {
    @Binding var path: [AppRoute]
    @State private var appeared = false
    
    var body: some View {
        VStack(spacing: 0) {
            navigationBar
            
            ScrollView(showsIndicators: false) {
                VStack(spacing: 25) {
                    reportHeaderCard
                    mainReportBody
                    downloadButton
                    
                    Spacer(minLength: 40)
                }
                .padding()
            }
        }
        .background(Color(hex: "F8FBF9").ignoresSafeArea())
        .onAppear {
            appeared = true
        }
    }
    
    // MARK: - Subviews
    
    private var navigationBar: some View {
        HStack {
            Button(action: {
                if !path.isEmpty {
                    _ = path.removeLast()
                }
            }) {
                Image(systemName: "arrow.left")
                    .font(.title3.bold())
                    .foregroundColor(.primary)
                    .padding(12)
                    .background(Color.white)
                    .clipShape(Circle())
                    .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
            }
            Text("Report Preview")
                .font(.system(size: 20, weight: .bold))
                .padding(.leading, 10)
            Spacer()
            
            Button(action: {
                path.append(.shareReport)
            }) {
                Image(systemName: "square.and.arrow.up")
                    .font(.body.bold())
                    .foregroundColor(.green)
                    .padding(12)
                    .background(Color.green.opacity(0.1))
                    .clipShape(Circle())
            }
        }
        .padding()
        .background(Color(.systemBackground))
    }
    
    private var reportHeaderCard: some View {
        HStack(spacing: 20) {
            ZStack {
                RoundedRectangle(cornerRadius: 15)
                    .fill(Color.indigo.opacity(0.08))
                    .frame(width: 56, height: 56)
                Image(systemName: "doc.text.fill")
                    .font(.title3)
                    .foregroundColor(.indigo)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text("Monthly Report")
                    .font(.title3.bold())
                HStack {
                    Image(systemName: "calendar")
                        .font(.caption)
                    Text("February 2026")
                        .font(.subheadline)
                }
                .foregroundColor(.secondary)
            }
            Spacer()
        }
        .padding(25)
        .background(Color.white)
        .cornerRadius(30)
        .shadow(color: Color.black.opacity(0.04), radius: 15, x: 0, y: 10)
        .scaleEffect(appeared ? 1 : 0.95)
        .opacity(appeared ? 1 : 0)
        .animation(.spring(response: 0.6, dampingFraction: 0.75).delay(0.1), value: appeared)
    }
    
    private var mainReportBody: some View {
        VStack(spacing: 30) {
            Text("Herd Performance Summary")
                .font(.headline)
            
            // Sections
            ReportSection(title: "Overview", items: [
                ReportRow(label: "Total Animals:", value: "24"),
                ReportRow(label: "Lactating:", value: "18"),
                ReportRow(label: "Total Scans:", value: "127")
            ])
            
            Divider().background(Color.gray.opacity(0.1))
            
            ReportSection(title: "Production Metrics", items: [
                ReportRow(label: "Avg Daily Yield:", value: "15.3 L"),
                ReportRow(label: "Total Production:", value: "8,250 L"),
                ReportRow(label: "Revenue Generated:", value: "$24,750", color: .green)
            ])
            
            Divider().background(Color.gray.opacity(0.1))
            
            ReportSection(title: "Health & Care", items: [
                ReportRow(label: "Herd Health Score:", value: "95%", color: .green),
                ReportRow(label: "Vaccinations Done:", value: "18"),
                ReportRow(label: "Disease Risk:", value: "Low", color: .orange)
            ])
            
            Divider().background(Color.gray.opacity(0.1))
            
            ReportSection(title: "Economic Analysis", items: [
                ReportRow(label: "Total Expenses:", value: "$12,480"),
                ReportRow(label: "Net Profit:", value: "$12,270", color: .green),
                ReportRow(label: "ROI:", value: "98.3%", color: .green)
            ])
        }
        .padding(30)
        .background(Color.white)
        .cornerRadius(32)
        .shadow(color: Color.black.opacity(0.05), radius: 20, x: 0, y: 10)
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 30)
        .animation(.spring(response: 0.7, dampingFraction: 0.8).delay(0.2), value: appeared)
    }
    
    private var downloadButton: some View {
        Button(action: {}) {
            Text("Download Full PDF Report")
                .font(.headline)
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 18)
                .background(Color.green)
                .cornerRadius(18)
                .shadow(color: Color.green.opacity(0.3), radius: 10, x: 0, y: 5)
        }
        .padding(.top, 10)
        .opacity(appeared ? 1 : 0)
        .animation(.spring().delay(0.4), value: appeared)
    }
}

struct ReportSection: View {
    let title: String
    let items: [ReportRow]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text(title)
                .font(.system(size: 15, weight: .bold))
                .foregroundColor(.secondary)
                .kerning(1)
            
            VStack(spacing: 14) {
                ForEach(0..<items.count, id: \.self) { i in
                    items[i]
                }
            }
        }
    }
}

struct ReportRow: View {
    let label: String
    let value: String
    var color: Color = .primary
    
    var body: some View {
        HStack {
            Text(label)
                .foregroundColor(.secondary)
            Spacer()
            Text(value)
                .font(.system(size: 16, weight: .bold))
                .foregroundColor(color)
        }
    }
}

#Preview {
    ReportPreviewView(path: .constant([]))
}
