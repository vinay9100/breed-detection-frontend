import SwiftUI

struct BPAReportsView: View {
    @Binding var path: [AppRoute]
    @State private var appeared = false
    
    var body: some View {
        ZStack {
            Color(hex: "F8FBF9").ignoresSafeArea()
            
            VStack(spacing: 0) {
                reportsHeader
                
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 25) {
                        mainReportCard
                        registrationSummaryTable
                        breedStatisticsTable
                        verificationReportPreview
                        downloadSection
                        autoRefreshNote
                        
                        Spacer(minLength: 40)
                    }
                    .padding(24)
                }
            }
        }
        .onAppear {
            withAnimation(.easeOut(duration: 0.6)) {
                appeared = true
            }
        }
    }
    
    private var reportsHeader: some View {
        VStack(spacing: 15) {
            HStack(spacing: 20) {
                Button(action: {
                    if !path.isEmpty {
                        _ = path.removeLast()
                    }
                }) {
                    Image(systemName: "arrow.left")
                        .font(.title3.bold())
                        .foregroundColor(.white)
                }
                
                VStack(alignment: .leading, spacing: 2) {
                    Text("BPA Reports")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.white)
                    Text("Export and share comprehensive reports")
                        .font(.system(size: 14))
                        .foregroundColor(.white.opacity(0.8))
                }
                
                Spacer()
            }
            .padding(.horizontal, 24)
            .padding(.top, 20)
            .padding(.bottom, 25)
        }
        .background(
            LinearGradient(
                colors: [Color(hex: "00C853"), Color(hex: "008D43")],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
        )
    }
    
    private var mainReportCard: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("February 2026 Report")
                        .font(.system(size: 18, weight: .bold))
                    Text("Generated on Feb 13, 2026")
                        .font(.system(size: 14))
                        .foregroundColor(.secondary)
                }
                Spacer()
                HStack(spacing: 12) {
                    IconButton(icon: "slider.horizontal.3")
                    IconButton(icon: "calendar")
                }
            }
            
            HStack(spacing: 12) {
                ReportActionButton(title: "Export", icon: nil)
                ReportActionButton(title: "Share", icon: nil)
                ReportActionButton(title: "Print", icon: "plus", isSpecial: true)
            }
        }
        .padding(24)
        .background(Color.white)
        .cornerRadius(24)
        .shadow(color: Color.black.opacity(0.04), radius: 15, x: 0, y: 10)
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 20)
        .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.1), value: appeared)
    }
    
    private var registrationSummaryTable: some View {
        TableCard(title: "Animal Registration Summary", icon: "doc.text.fill") {
            VStack(spacing: 0) {
                TableHeader(columns: ["Ear Tag", "Breed", "Owner"])
                
                InteractiveTableRow(path: $path, data: ["ET-20-24-8-472", "Holstein Friesian", "Ramesh Kumar"])
                InteractiveTableRow(path: $path, data: ["ET-20-24-8-469", "Murrah Buffalo", "Suresh Patel"])
                InteractiveTableRow(path: $path, data: ["ET-20-24-8-455", "Gir", "Amit Singh"])
                InteractiveTableRow(path: $path, data: ["ET-20-24-8-431", "Jersey", "Anil Reddy"], isLast: true)
            }
            
            Text("Showing 5 of 2,847 total registrations")
                .font(.system(size: 11))
                .foregroundColor(.secondary)
                .padding(.top, 15)
        }
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 20)
        .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.2), value: appeared)
    }
    

    
    private var breedStatisticsTable: some View {
        TableCard(title: "Breed Statistics", icon: "chart.pie.fill", titleColor: .purple) {
            VStack(spacing: 0) {
                TableHeader(columns: ["Breed", "Count", "%"], color: .purple)
                TableRow(data: ["Holstein Friesian", "782", "27.5%"])
                TableRow(data: ["Murrah Buffalo", "654", "23.0%"])
                TableRow(data: ["Gir", "521", "18.3%"])
                TableRow(data: ["Sahiwal", "438", "15.4%"])
                TableRow(data: ["Jersey", "312", "11.0%"])
                TableRow(data: ["Others", "140", "4.8%"], isLast: true)
            }
            .padding(.bottom, 10)
            
            Divider()
            
            HStack {
                Text("Total: 2,847 animals")
                    .font(.system(size: 12, weight: .bold))
                Spacer()
                Text("2,810 verified (98.7%)")
                    .font(.system(size: 12, weight: .bold))
                    .foregroundColor(Color(hex: "00C853"))
            }
            .padding(.top, 10)
        }
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 20)
        .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.4), value: appeared)
    }
    
    private var verificationReportPreview: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                Image(systemName: "doc.badge.checkmark.fill")
                    .foregroundColor(.orange)
                Text("Verification Report Preview")
                    .font(.system(size: 18, weight: .bold))
            }
            
            HStack(spacing: 15) {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Total Verified")
                        .font(.system(size: 12))
                        .foregroundColor(.secondary)
                    Text("2,810")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(Color(hex: "00C853"))
                    Text("98.7% completion")
                        .font(.system(size: 11))
                        .foregroundColor(Color(hex: "00C853"))
                }
                .padding(15)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color(hex: "00C853").opacity(0.05))
                .cornerRadius(16)
                
                VStack(alignment: .leading, spacing: 8) {
                    Text("Pending")
                        .font(.system(size: 12))
                        .foregroundColor(.secondary)
                    Text("37")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.orange)
                    Text("1.3% remaining")
                        .font(.system(size: 11))
                        .foregroundColor(.orange)
                }
                .padding(15)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.orange.opacity(0.05))
                .cornerRadius(16)
            }
            
            VStack(alignment: .leading, spacing: 12) {
                Text("Verification Breakdown")
                    .font(.system(size: 14, weight: .bold))
                
                BreakdownRow(label: "AI Auto-verified", value: "2,554 (83.2%)")
                BreakdownRow(label: "Manual verification", value: "156 (5.5%)")
                BreakdownRow(label: "Awaiting review", value: "37 (1.3%)", color: .orange)
            }
            .padding(20)
            .background(Color.gray.opacity(0.03))
            .cornerRadius(16)
        }
        .padding(24)
        .background(Color.white)
        .cornerRadius(24)
        .shadow(color: Color.black.opacity(0.04), radius: 15, x: 0, y: 10)
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 20)
        .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.5), value: appeared)
    }
    
    private var downloadSection: some View {
        VStack(spacing: 20) {
            ZStack {
                Circle()
                    .fill(Color(hex: "00C853").opacity(0.1))
                    .frame(width: 50, height: 50)
                Image(systemName: "arrow.down.to.line")
                    .font(.title2)
                    .foregroundColor(Color(hex: "00C853"))
            }
            
            VStack(spacing: 8) {
                Text("Download Complete Report")
                    .font(.system(size: 16, weight: .bold))
                Text("Export the complete report in PDF or\nExcel format with all detailed analytics and\ntables.")
                    .font(.system(size: 13))
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
            
            HStack(spacing: 15) {
                Button(action: {}) {
                    Text("Preview & Download")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(Color(hex: "008D43"))
                        .cornerRadius(12)
                }
                
                Button(action: {}) {
                    Text("Download Excel")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(Color(hex: "00C853"))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color(hex: "00C853").opacity(0.3), lineWidth: 1))
                }
            }
        }
        .padding(30)
        .background(Color(hex: "00C853").opacity(0.05))
        .cornerRadius(24)
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 20)
        .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.6), value: appeared)
    }
    
    private var autoRefreshNote: some View {
        HStack {
            Image(systemName: "chart.bar.fill")
                .foregroundColor(.blue)
            Text("Reports are automatically generated and\nupdated in real-time")
                .font(.system(size: 12, weight: .medium))
                .foregroundColor(.blue.opacity(0.8))
            Spacer()
        }
        .padding(15)
        .background(Color.blue.opacity(0.05))
        .cornerRadius(12)
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 20)
        .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.7), value: appeared)
    }
}

// MARK: - Components

struct IconButton: View {
    let icon: String
    var body: some View {
        Image(systemName: icon)
            .padding(10)
            .background(Color.gray.opacity(0.1))
            .clipShape(Circle())
            .foregroundColor(.secondary)
    }
}

struct ReportActionButton: View {
    let title: String
    let icon: String?
    var isSpecial: Bool = false
    
    var body: some View {
        HStack {
            if let icon = icon {
                Image(systemName: icon)
                    .font(.system(size: 12, weight: .bold))
            }
            Text(title)
                .font(.system(size: 14, weight: .bold))
        }
        .foregroundColor(Color(hex: "008D43"))
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color(hex: "008D43").opacity(0.4), lineWidth: 1.5))
    }
}

struct TableCard<Content: View>: View {
    let title: String
    let icon: String
    var titleColor: Color = Color(hex: "1B5E20")
    @ViewBuilder let content: Content
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                Image(systemName: icon)
                    .foregroundColor(titleColor)
                Text(title)
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(titleColor)
            }
            
            content
        }
        .padding(24)
        .background(Color.white)
        .cornerRadius(24)
        .shadow(color: Color.black.opacity(0.04), radius: 15, x: 0, y: 10)
    }
}

struct TableHeader: View {
    let columns: [String]
    var color: Color = Color(hex: "1B5E20")
    
    var body: some View {
        HStack {
            ForEach(columns, id: \.self) { col in
                Text(col)
                    .font(.system(size: 12, weight: .bold))
                    .foregroundColor(color)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .padding(.vertical, 12)
        .background(color.opacity(0.05))
        .cornerRadius(8)
        .padding(.bottom, 10)
    }
}

enum TableRowStatus {
    case none, verified, pending
}

struct TableRow: View {
    let data: [String]
    var status: TableRowStatus = .none
    var counts: [Int]? = nil // indices to show as badges
    var isCountZero: [Bool]? = nil
    var isLast: Bool = false
    var isCountHighlight: Bool = false
    
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                ForEach(0..<data.count, id: \.self) { i in
                    Group {
                        if i == data.count - 1 && status != .none {
                            Text(data[i])
                                .font(.system(size: 11, weight: .bold))
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(status == .verified ? Color(hex: "00C853").opacity(0.1) : Color.orange.opacity(0.1))
                                .foregroundColor(status == .verified ? Color(hex: "00C853") : .orange)
                                .cornerRadius(6)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        } else if counts?.contains(i) ?? false {
                            let idx = counts?.firstIndex(of: i) ?? 0
                            let zero = isCountZero?[idx] ?? false
                            Text(data[i])
                                .font(.system(size: 11, weight: .bold))
                                .padding(6)
                                .frame(width: 24, height: 24)
                                .background(zero ? Color(hex: "00C853").opacity(0.1) : Color.orange.opacity(0.1))
                                .foregroundColor(zero ? Color(hex: "00C853") : .orange)
                                .clipShape(Circle())
                                .frame(maxWidth: .infinity, alignment: .leading)
                        } else {
                            Text(data[i])
                                .font(.system(size: 11, weight: i == 0 || isCountHighlight ? .bold : .medium))
                                .foregroundColor(i == data.count - 1 && isCountHighlight ? Color(hex: "00C853") : .secondary)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                    }
                }
            }
            .padding(.vertical, 15)
            
            if !isLast {
                Divider()
            }
        }
    }
}

struct BreakdownRow: View {
    let label: String
    let value: String
    var color: Color = .secondary
    
    var body: some View {
        HStack {
            Text(label)
                .font(.system(size: 13))
                .foregroundColor(.secondary)
            Spacer()
            Text(value)
                .font(.system(size: 13, weight: .bold))
                .foregroundColor(color == .secondary ? .primary : color)
        }
    }
}


struct InteractiveTableRow: View {
    @Binding var path: [AppRoute]
    let data: [String]
    var isLast: Bool = false
    
    var body: some View {
        Button(action: {
            path.append(.bpaAnimalDetail)
        }) {
            VStack(spacing: 0) {
                HStack {
                    ForEach(0..<data.count, id: \.self) { i in
                        Text(data[i])
                            .font(.system(size: 11, weight: i == 0 ? .bold : .medium))
                            .foregroundColor(i == 0 ? Color(hex: "00C853") : .primary)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    Image(systemName: "chevron.right")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(.gray.opacity(0.4))
                }
                .padding(.vertical, 15)
                .contentShape(Rectangle()) // makes entire row tappable
                
                if !isLast {
                    Divider()
                }
            }
        }
        .buttonStyle(PlainButtonStyle())
    }
}

#Preview {
    BPAReportsView(path: .constant([]))
}
