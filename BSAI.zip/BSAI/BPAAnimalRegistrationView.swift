import SwiftUI

struct BPAAnimalRegistrationView: View {
    @Binding var path: [AppRoute]
    
    // Form States
    @State private var earTagNumber = ""
    @State private var species = ""
    @State private var sex = ""
    @State private var breed = ""
    @State private var dob = ""
    @State private var ownerName = ""
    @State private var phoneNumber = ""
    @State private var address = ""
    @State private var village = ""
    @State private var district = ""
    @State private var stateName = ""
    
    @State private var appeared = false
    
    var body: some View {
        ZStack {
            Color(hex: "F8FBF9").ignoresSafeArea()
            
            VStack(spacing: 0) {
                headerSection
                
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 25) {
                        animalInformationCard
                        ownerInformationCard
                        
                        actionButtons
                        
                        Spacer(minLength: 40)
                    }
                    .padding(24)
                    .padding(.top, -30)
                }
            }
        }
        .onAppear {
            withAnimation(.easeOut(duration: 0.6)) {
                appeared = true
            }
        }
    }
    
    private var headerSection: some View {
        VStack(spacing: 15) {
            HStack(spacing: 20) {
                Button(action: {
                    if !path.isEmpty {
                        _ = path.removeLast()
                    }
                }) {
                    HStack(spacing: 8) {
                        Image(systemName: "arrow.left")
                            .font(.title3.bold())
                        Text("Back to Dashboard")
                            .font(.system(size: 16, weight: .medium))
                    }
                    .foregroundColor(.white)
                }
                
                VStack(alignment: .leading, spacing: 2) {
                    Text("Animal Registration")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.white)
                    Text("Register new animal with AI assistance")
                        .font(.system(size: 14))
                        .foregroundColor(.white.opacity(0.8))
                }
                
                Spacer()
            }
            .padding(.horizontal, 24)
            .padding(.top, 40)
            .padding(.bottom, 60)
        }
        .background(
            LinearGradient(
                colors: [Color(hex: "00C853"), Color(hex: "008D43")],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
        )
    }
    
    private var animalInformationCard: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                ZStack {
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Color(hex: "00C853").opacity(0.1))
                        .frame(width: 36, height: 36)
                    Image(systemName: "tag.fill")
                        .foregroundColor(Color(hex: "00C853"))
                }
                Text("Animal Information")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(Color(hex: "1B5E20"))
            }
            
            VStack(alignment: .leading, spacing: 15) {
                inputField(label: "Ear Tag Number *", placeholder: "ET-2024-XXXX", text: $earTagNumber)
                
                HStack(spacing: 15) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Species *")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(.primary.opacity(0.8))
                        
                        Menu {
                            Button("Cattle") { species = "Cattle" }
                            Button("Buffalo") { species = "Buffalo" }
                        } label: {
                            HStack {
                                Text(species.isEmpty ? "Select" : species)
                                    .foregroundColor(species.isEmpty ? .secondary : .primary)
                                Spacer()
                                Image(systemName: "chevron.down")
                                    .font(.system(size: 12))
                                    .foregroundColor(.secondary)
                            }
                            .padding()
                            .background(Color.gray.opacity(0.05))
                            .cornerRadius(12)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Sex *")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(.primary.opacity(0.8))
                        
                        Menu {
                            Button("Male") { sex = "Male" }
                            Button("Female") { sex = "Female" }
                        } label: {
                            HStack {
                                Text(sex.isEmpty ? "Select" : sex)
                                    .foregroundColor(sex.isEmpty ? .secondary : .primary)
                                Spacer()
                                Image(systemName: "chevron.down")
                                    .font(.system(size: 12))
                                    .foregroundColor(.secondary)
                            }
                            .padding()
                            .background(Color.gray.opacity(0.05))
                            .cornerRadius(12)
                        }
                    }
                    .frame(maxWidth: .infinity)
                }
                
                VStack(alignment: .leading, spacing: 8) {
                    Text("Breed (AI-Assisted)")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(.primary.opacity(0.8))
                    
                    HStack {
                        TextField("Use AI camera to detect", text: $breed)
                            .font(.system(size: 15))
                        
                        Button(action: {
                            path.append(.bpaCamera)
                        }) {
                            HStack(spacing: 6) {
                                Image(systemName: "camera.fill")
                                Text("AI Scan")
                            }
                            .font(.system(size: 14, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 10)
                            .background(Color(hex: "008D43"))
                            .cornerRadius(10)
                        }
                    }
                    .padding(8)
                    .padding(.leading, 8)
                    .background(Color(hex: "F3F6FF"))
                    .cornerRadius(12)

                    
                    HStack(spacing: 4) {
                        Image(systemName: "sparkles")
                            .font(.system(size: 12))
                        Text("Automatically detect breed using AI camera")
                            .font(.system(size: 11))
                    }
                    .foregroundColor(.purple)
                }
                
                VStack(alignment: .leading, spacing: 8) {
                    Text("Date of Birth")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(.primary.opacity(0.8))
                    
                    HStack {
                        TextField(" ", text: $dob)
                            .font(.system(size: 15))
                        Image(systemName: "calendar")
                            .foregroundColor(.secondary)
                    }
                    .padding()
                    .background(Color.gray.opacity(0.05))
                    .cornerRadius(12)

                }
            }
        }
        .padding(24)
        .background(Color.white)
        .cornerRadius(24)
        .shadow(color: Color.black.opacity(0.04), radius: 15, x: 0, y: 10)
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 20)
        .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.1), value: appeared)
    }
    
    private var ownerInformationCard: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                ZStack {
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Color.blue.opacity(0.1))
                        .frame(width: 36, height: 36)
                    Image(systemName: "person.fill")
                        .foregroundColor(.blue)
                }
                Text("Owner Information")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(Color(hex: "1B5E20"))
            }
            
            VStack(alignment: .leading, spacing: 15) {
                inputField(label: "Owner Name *", placeholder: "Full name", text: $ownerName)
                
                VStack(alignment: .leading, spacing: 8) {
                    Text("Phone Number *")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(.primary.opacity(0.8))
                    
                    HStack(spacing: 12) {
                        Image(systemName: "phone")
                            .foregroundColor(.secondary)
                        TextField("+91 XXXXXXXXXX", text: $phoneNumber)
                            .font(.system(size: 15))
                    }
                    .padding()
                    .background(Color.gray.opacity(0.05))
                    .cornerRadius(12)

                }
                
                inputField(label: "Address", placeholder: "Street address", text: $address)
                
                HStack(spacing: 15) {
                    inputField(label: "Village *", placeholder: "Village name", text: $village)
                    inputField(label: "District *", placeholder: "District", text: $district)
                }
                
                inputField(label: "State *", placeholder: "State name", text: $stateName)
            }
        }
        .padding(24)
        .background(Color.white)
        .cornerRadius(24)
        .shadow(color: Color.black.opacity(0.04), radius: 15, x: 0, y: 10)
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 20)
        .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.2), value: appeared)
    }
    
    private var actionButtons: some View {
        VStack(spacing: 12) {
            Button(action: {
                path.append(.bpaRegistrationReview)
            }) {
                Text("Continue to Review")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 18)
                    .background(
                        LinearGradient(
                            colors: [Color(hex: "2962FF"), Color(hex: "1565C0")],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .cornerRadius(14)
            }
            .buttonStyle(ScaleButtonStyle())
            
            Button(action: {
                if !path.isEmpty {
                    path.removeLast()
                }
            }) {
                Text("Cancel")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(Color(hex: "1B5E20"))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 18)
                    .background(Color.white)
                    .cornerRadius(14)
                    .overlay(
                        RoundedRectangle(cornerRadius: 14)
                            .stroke(Color.gray.opacity(0.2), lineWidth: 1)
                    )
            }
            .buttonStyle(ScaleButtonStyle())
        }
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 20)
        .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.3), value: appeared)
    }
    
    private func inputField(label: String, placeholder: String, text: Binding<String>) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(label)
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(.primary.opacity(0.8))
            
            TextField(placeholder, text: text)
                .font(.system(size: 15))
                .padding()
                .background(Color.gray.opacity(0.05))
                .cornerRadius(12)

        }
    }
}

#Preview {
    BPAAnimalRegistrationView(path: .constant([]))
}
