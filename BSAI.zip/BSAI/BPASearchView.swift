import SwiftUI

struct BPASearchView: View {
    @Binding var path: [AppRoute]
    @State private var searchText = ""
    @State private var appeared = false
    
    var body: some View {
        ZStack {
            Color(hex: "F8FBF9").ignoresSafeArea()
            
            VStack(spacing: 0) {
                searchHeader
                
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 30) {
                        searchBarCard
                        
                        if searchText.isEmpty {
                            quickFiltersSection
                            recentSearchesSection
                        } else {
                            searchResultsSection
                        }
                        
                        Spacer(minLength: 40)
                    }
                    .padding(.top, -30)
                }
            }
        }
        .onAppear {
            withAnimation(.easeOut(duration: 0.6)) {
                appeared = true
            }
        }
    }
    
    private var searchHeader: some View {
        VStack(spacing: 15) {
            HStack(alignment: .top) {
                Button(action: {
                    if !path.isEmpty {
                        _ = path.removeLast()
                    }
                }) {
                    Image(systemName: "arrow.left")
                        .font(.title3.bold())
                        .foregroundColor(.white)
                }
                
                VStack(alignment: .leading, spacing: 5) {
                    Text("Search Animal")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundColor(.white)
                    Text("Find by Ear Tag ID, Owner, or Location")
                        .font(.system(size: 14))
                        .foregroundColor(.white.opacity(0.8))
                }
                
                Spacer()
            }
            .padding(.horizontal, 24)
            .padding(.top, 40)
            .padding(.bottom, 60)
        }
        .background(
            LinearGradient(
                colors: [Color(hex: "00C853"), Color(hex: "008D43")],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
        )
    }
    
    private var searchBarCard: some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack(spacing: 15) {
                Image(systemName: "magnifyingglass")
                    .font(.title2)
                    .foregroundColor(.secondary)
                
                TextField("Enter Ear Tag ID, Owner Name, or Villa...", text: $searchText)
                    .font(.system(size: 16))
            }
            .padding(20)
            .background(Color.blue.opacity(0.05))
            .cornerRadius(16)
            .overlay(
                RoundedRectangle(cornerRadius: 16)
                    .stroke(Color.blue.opacity(0.15), lineWidth: 1)
            )
            
            Text("Start typing to search")
                .font(.system(size: 13))
                .foregroundColor(.secondary)
                .padding(.leading, 5)
        }
        .padding(24)
        .background(Color.white)
        .cornerRadius(24)
        .shadow(color: Color.black.opacity(0.04), radius: 15, x: 0, y: 10)
        .padding(.horizontal, 24)
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 20)
        .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.1), value: appeared)
    }
    
    private var quickFiltersSection: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Quick Filters")
                .font(.system(size: 16, weight: .bold))
                .foregroundColor(Color(hex: "1B5E20"))
                .padding(.horizontal, 24)
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    FilterCapsule(label: "Recently Added")
                    FilterCapsule(label: "Pending Verification")
                    FilterCapsule(label: "Cattle Only")
                    FilterCapsule(label: "Buffalo Only")
                }
                .padding(.horizontal, 24)
            }
        }
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 20)
        .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.2), value: appeared)
    }
    
    private var recentSearchesSection: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Recent Searches")
                .font(.system(size: 16, weight: .bold))
                .foregroundColor(Color(hex: "1B5E20"))
                .padding(.horizontal, 24)
            
            VStack(spacing: 12) {
                RecentSearchRow(label: "ET-2024-8470")
                RecentSearchRow(label: "Rajesh Kumar")
                RecentSearchRow(label: "Vadodara")
            }
            .padding(.horizontal, 24)
        }
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 20)
        .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.3), value: appeared)
    }

    private var searchResultsSection: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Search Results")
                .font(.system(size: 16, weight: .bold))
                .foregroundColor(Color(hex: "1B5E20"))
                .padding(.horizontal, 24)
            
            VStack(spacing: 12) {
                SearchResultRow(id: "ET-2024-8472", breed: "Holstein Friesian", owner: "Ramesh Kumar") {
                    path.append(.bpaAnimalDetail)
                }
                SearchResultRow(id: "ET-2024-8469", breed: "Murrah Buffalo", owner: "Suresh Patel") {
                    path.append(.bpaAnimalDetail)
                }
                SearchResultRow(id: "ET-2024-8455", breed: "Gir Cattle", owner: "Amit Singh") {
                    path.append(.bpaAnimalDetail)
                }
            }
            .padding(.horizontal, 24)
        }
    }
}

struct SearchResultRow: View {
    let id: String
    let breed: String
    let owner: String
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 16) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color(hex: "00C853").opacity(0.1))
                        .frame(width: 48, height: 48)
                    Image(systemName: "pawprint.fill")
                        .foregroundColor(Color(hex: "00C853"))
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(id)
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(Color(hex: "1B5E20"))
                    Text("\(breed) • \(owner)")
                        .font(.system(size: 13))
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                Image(systemName: "chevron.right")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(.gray.opacity(0.4))
            }
            .padding(16)
            .background(Color.white)
            .cornerRadius(18)
            .shadow(color: Color.black.opacity(0.02), radius: 5, x: 0, y: 2)
            .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.gray.opacity(0.1), lineWidth: 1))
        }
    }
}

struct FilterCapsule: View {
    let label: String
    var body: some View {
        Text(label)
            .font(.system(size: 14, weight: .medium))
            .padding(.horizontal, 20)
            .padding(.vertical, 12)
            .background(Color.white)
            .cornerRadius(14)
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.gray.opacity(0.15), lineWidth: 1))
            .foregroundColor(Color(hex: "1B5E20"))
    }
}

struct RecentSearchRow: View {
    let label: String
    var body: some View {
        HStack(spacing: 15) {
            Image(systemName: "magnifyingglass")
                .foregroundColor(.secondary)
            Text(label)
                .font(.system(size: 15))
                .foregroundColor(.primary.opacity(0.8))
            Spacer()
        }
        .padding(18)
        .background(Color.white)
        .cornerRadius(14)
        .shadow(color: Color.black.opacity(0.02), radius: 5, x: 0, y: 2)
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.gray.opacity(0.1), lineWidth: 1))
    }
}

#Preview {
    BPASearchView(path: .constant([]))
}
