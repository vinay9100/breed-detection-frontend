import SwiftUI

struct BPAAnalyticsView: View {
    @Binding var path: [AppRoute]
    @State private var appeared = false
    @State private var selectedBreed: String? = nil
    @State private var selectedBarIndex: Int? = nil
    @State private var timeFilter = "Week"
    let timeFilters = ["Week", "15 Days", "30 Days", "Custom"]
    @State private var customStartDate = Date().addingTimeInterval(-86400 * 7)
    @State private var customEndDate = Date()
    
    // Mock Data Struct for Interactive Donut Array
    struct BreedData: Identifiable {
        let id = UUID()
        let name: String
        let count: Int
        let color: Color
    }
    
    var breedData: [BreedData] {
        if timeFilter == "Week" {
            return [
                BreedData(name: "Holstein Friesia", count: 45, color: Color(hex: "00C853")),
                BreedData(name: "Murrah Buffalo", count: 42, color: .blue),
                BreedData(name: "Gir", count: 18, color: .orange),
                BreedData(name: "Sahiwal", count: 14, color: .red),
                BreedData(name: "Jersey", count: 6, color: .purple),
                BreedData(name: "Others", count: 2, color: .gray)
            ]
        } else if timeFilter == "15 Days" {
            return [
                BreedData(name: "Holstein Friesia", count: 120, color: Color(hex: "00C853")),
                BreedData(name: "Murrah Buffalo", count: 105, color: .blue),
                BreedData(name: "Gir", count: 70, color: .orange),
                BreedData(name: "Sahiwal", count: 55, color: .red),
                BreedData(name: "Jersey", count: 30, color: .purple),
                BreedData(name: "Others", count: 15, color: .gray)
            ]
        } else if timeFilter == "30 Days" {
            return [
                BreedData(name: "Holstein Friesia", count: 250, color: Color(hex: "00C853")),
                BreedData(name: "Murrah Buffalo", count: 210, color: .blue),
                BreedData(name: "Gir", count: 150, color: .orange),
                BreedData(name: "Sahiwal", count: 110, color: .red),
                BreedData(name: "Jersey", count: 60, color: .purple),
                BreedData(name: "Others", count: 30, color: .gray)
            ]
        } else { // Custom
             return [
                BreedData(name: "Holstein Friesia", count: 4425, color: Color(hex: "00C853")),
                BreedData(name: "Murrah Buffalo", count: 3870, color: .blue),
                BreedData(name: "Gir", count: 2950, color: .orange),
                BreedData(name: "Sahiwal", count: 2190, color: .red),
                BreedData(name: "Jersey", count: 1210, color: .purple),
                BreedData(name: "Others", count: 603, color: .gray)
            ]
        }
    }
    
    var body: some View {
        ZStack {
            Color(hex: "F8FBF9").ignoresSafeArea()
            
            VStack(spacing: 0) {
                analyticsHeader
                
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 25) {
                        Picker("Time Range", selection: $timeFilter) {
                            ForEach(timeFilters, id: \.self) {
                                Text($0)
                            }
                        }
                        .pickerStyle(SegmentedPickerStyle())
                        .padding(.horizontal, 4)
                        .padding(.top, 10)
                        
                        // Custom Date Range Picker
                        if timeFilter == "Custom" {
                            HStack(spacing: 12) {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text("Start Date").font(.system(size: 11)).foregroundColor(.secondary)
                                    DatePicker("", selection: $customStartDate, displayedComponents: .date)
                                        .labelsHidden()
                                        .environment(\.locale, Locale(identifier: "en_GB")) // Forces day-month-year style
                                }
                                
                                VStack(alignment: .leading, spacing: 4) {
                                    Text("End Date").font(.system(size: 11)).foregroundColor(.secondary)
                                    DatePicker("", selection: $customEndDate, displayedComponents: .date)
                                        .labelsHidden()
                                        .environment(\.locale, Locale(identifier: "en_GB"))
                                }
                            }
                            .padding(.vertical, 8)
                            .padding(.horizontal, 16)
                            .background(Color(.systemGray6))
                            .cornerRadius(12)
                            .opacity(appeared ? 1 : 0)
                            .animation(.spring(response: 0.4, dampingFraction: 0.7), value: timeFilter)
                        }
                        
                        dailyRegistrationsCard
                        breedDistributionCard
                        verificationStatusCard
                        aiDetectionAccuracyCard
                        monthlyTrendComparisonCard
                        
                        analyticsSummaryCard
                        
                        Spacer(minLength: 40)
                    }
                    .padding(24)
                }
            }
        }
        .onAppear {
            withAnimation(.easeOut(duration: 0.6)) {
                appeared = true
            }
        }
    }
    
    // MARK: - Subviews
    
    private var analyticsHeader: some View {
        VStack(spacing: 15) {
            HStack(spacing: 20) {
                Button(action: { 
                    if !path.isEmpty {
                        _ = path.removeLast()
                    }
                }) {
                    Image(systemName: "arrow.left")
                        .font(.title3.bold())
                        .foregroundColor(.white)
                }
                
                VStack(alignment: .leading, spacing: 2) {
                    Text("BPA Analytics")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.white)
                    Text("Comprehensive data insights")
                        .font(.system(size: 14))
                        .foregroundColor(.white.opacity(0.8))
                }
                
                Spacer()
            }
            .padding(.horizontal, 24)
            .padding(.top, 50) // Explicit padding to clear Dynamic Island / Notch
            .padding(.bottom, 25)
        }
        .background(
            LinearGradient(
                colors: [Color(hex: "00C853"), Color(hex: "008D43")],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
        )
    }
    
    private var dailyRegistrationsCard: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                Image(systemName: "chart.bar.fill")
                    .foregroundColor(Color(hex: "00C853"))
                Text(timeFilter == "Week" ? "Daily Registrations" : (timeFilter == "15 Days" ? "Daily Registrations" : (timeFilter == "30 Days" ? "Daily Registrations" : "Total Registrations")))
                    .font(.system(size: 18, weight: .bold))
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text(timeFilter == "Week" ? "Last 7 days" : (timeFilter == "15 Days" ? "Last 15 days" : (timeFilter == "30 Days" ? "Last 30 days" : "Since beginning")))
                    .font(.system(size: 14))
                    .foregroundColor(.secondary)
                Text(timeFilter == "Week" ? "Average: 46.4 per day" : (timeFilter == "15 Days" ? "Average: 35.7 per day" : (timeFilter == "30 Days" ? "Average: 45.3 per day" : "Average: 5,400 per year")))
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(Color(hex: "1B5E20"))
            }
            
            // Arrays for dynamic bar charts
            let weekData: [CGFloat] = [20, 35, 25, 55, 40, 65, 50]
            let fifteenDayData: [CGFloat] = [15, 22, 18, 25, 30, 28, 35, 40, 32, 45, 38, 50, 48, 55, 60]
            let thirtyDayData: [CGFloat] = [10, 15, 12, 18, 20, 25, 22, 28, 30, 25, 35, 40, 38, 45, 42, 50, 48, 55, 60, 58, 65, 70, 68, 75, 80, 78, 85, 90, 88, 95]
            let customData: [CGFloat] = [40, 50, 60, 45, 70, 80, 65, 85, 90, 75]
            
            let dataCount = timeFilter == "Week" ? 7 : (timeFilter == "15 Days" ? 15 : (timeFilter == "30 Days" ? 30 : 10))
            let currentData = timeFilter == "Week" ? weekData : (timeFilter == "15 Days" ? fifteenDayData : (timeFilter == "30 Days" ? thirtyDayData : customData))
            
            HStack(alignment: .bottom, spacing: timeFilter == "30 Days" ? 2 : (timeFilter == "15 Days" ? 6 : 18)) {
                ForEach(0..<dataCount, id: \.self) { i in
                    VStack(spacing: 8) {
                        // Tooltip
                        if selectedBarIndex == i {
                            Text("\(Int(currentData[i]))")
                                .font(.system(size: 10, weight: .bold))
                                .foregroundColor(.white)
                                .padding(.horizontal, 6)
                                .padding(.vertical, 4)
                                .background(Color.black.opacity(0.8))
                                .cornerRadius(4)
                                .offset(y: -4)
                        } else {
                            // Invisible spacer to prevent height jumping
                            Text(" ")
                                .font(.system(size: 10))
                                .padding(.vertical, 4)
                                .opacity(0)
                        }
                        
                        RoundedRectangle(cornerRadius: 2)
                            .fill(selectedBarIndex == i ? Color(hex: "00C853").opacity(0.8) : Color(hex: "00C853"))
                            .frame(width: timeFilter == "30 Days" ? 8 : (timeFilter == "15 Days" ? 14 : 28), height: currentData[i])
                            .onTapGesture {
                                withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                                    if selectedBarIndex == i {
                                        selectedBarIndex = nil
                                    } else {
                                        selectedBarIndex = i
                                    }
                                }
                            }
                        
                        // X-Axis specific day labels right beneath the bar
                        if timeFilter == "Week" {
                            let days = ["M", "T", "W", "T", "F", "S", "S"]
                            Text(days[i])
                                .font(.system(size: 10, weight: .medium))
                                .foregroundColor(.secondary)
                        } else if timeFilter == "15 Days" {
                            if i % 5 == 0 || i == 14 { // Label every 5th day and the last day
                                Text("\(i + 1)")
                                    .font(.system(size: 8))
                                    .foregroundColor(.secondary)
                            } else {
                                Text(" ").font(.system(size: 8))
                            }
                        } else if timeFilter == "30 Days" {
                            if i == 0 || i == 14 || i == 29 { // Label day 1, day 15, day 30
                                Text("\(i + 1)")
                                    .font(.system(size: 8))
                                    .foregroundColor(.secondary)
                            } else {
                                Text(" ").font(.system(size: 8))
                            }
                        }
                    }
                }
            }
            .frame(maxWidth: .infinity)
            .padding(.top, 10)
        }
        .padding(24)
        .background(Color.white)
        .cornerRadius(24)
        .shadow(color: Color.black.opacity(0.04), radius: 15, x: 0, y: 10)
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 20)
        .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.1), value: appeared)
    }
    
    private var breedDistributionCard: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                Image(systemName: "clock.fill")
                    .foregroundColor(.blue)
                Text("Breed-wise Distribution")
                    .font(.system(size: 18, weight: .bold))
            }
            
            HStack {
                Text("Total Animals: \(timeFilter == "Week" ? "127" : (timeFilter == "15 Days" ? "643" : "2,847"))")
                    .font(.system(size: 14))
                    .foregroundColor(.secondary)
                Spacer()
                Text(timeFilter)
                    .font(.system(size: 12, weight: .bold))
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Color.blue.opacity(0.1))
                    .foregroundColor(.blue)
                    .cornerRadius(8)
            }
            
            ZStack {
                // Background circle indicating 100% capacity
                Circle()
                    .fill(Color.gray.opacity(0.05))
                    .frame(width: 200, height: 200)
                
                // Solid Pie Segments
                let total = breedData.reduce(0) { $0 + $1.count }
                var currentAngle: Double = -90 // Start at top (12 o'clock)
                
                ForEach(breedData) { breed in
                    let fraction = Double(breed.count) / Double(total)
                    let degrees = fraction * 360.0
                    // Added a +0.5 degree overlap to endAngle to completely eliminate white rendering gaps
                    let endAngle = currentAngle + degrees + 0.5
                    
                    PieSlice(startAngle: .degrees(currentAngle), endAngle: .degrees(endAngle))
                        .fill(breed.color)
                        .scaleEffect(selectedBreed == breed.name ? 1.08 : 1.0)
                        .shadow(color: selectedBreed == breed.name ? breed.color.opacity(0.5) : .clear, radius: 10)
                        .zIndex(selectedBreed == breed.name ? 1 : 0) // Bring tapped slice to front
                        .onTapGesture {
                            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                                if selectedBreed == breed.name {
                                    selectedBreed = nil
                                } else {
                                    selectedBreed = breed.name
                                }
                            }
                        }
                    
                    let _ = { currentAngle = endAngle }()
                }
                
                // Central White Cutout to make it a thick ring, or keep it solid? The user specifically asked for "solid pie chart... should be fully circle", so we do NOT add a center cutout. It is a true pie chart.
                
                // Tooltip Overlay on tap
                if let selectedName = selectedBreed, let selectedObj = breedData.first(where: { $0.name == selectedName }) {
                     VStack(spacing: 4) {
                         Text(selectedObj.name)
                             .font(.system(size: 14, weight: .bold))
                             .multilineTextAlignment(.center)
                             .foregroundColor(.white)
                         Text("\(selectedObj.count) cows")
                             .font(.system(size: 12, weight: .medium))
                             .foregroundColor(.white.opacity(0.9))
                         Text("\(String(format: "%.1f", (Double(selectedObj.count) / Double(total)) * 100))%")
                             .font(.system(size: 16, weight: .black))
                             .foregroundColor(.white)
                     }
                     .padding(12)
                     .background(Color.black.opacity(0.75))
                     .cornerRadius(12)
                     .shadow(radius: 10)
                     .transition(.scale.combined(with: .opacity))
                     .id(selectedName)
                     .zIndex(2) // Above the pie
                }
            }
            .frame(width: 220, height: 220)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 20)
            
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                ForEach(breedData) { breed in
                    DistributionItem(label: breed.name, color: breed.color, value: "\(breed.count)")
                }
            }
        }
        .padding(24)
        .background(Color.white)
        .cornerRadius(24)
        .shadow(color: Color.black.opacity(0.04), radius: 15, x: 0, y: 10)
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 20)
        .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.2), value: appeared)
    }

    private var verificationStatusCard: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                Image(systemName: "checkmark.circle.fill")
                    .foregroundColor(.orange.opacity(0.8))
                Text("Verification Status")
                    .font(.system(size: 18, weight: .bold))
            }
            
            VStack(spacing: 20) {
                StatusRow(label: "Verified", value: "2810", total: "2847", color: Color(hex: "00C853"))
                StatusRow(label: "Pending", value: "37", total: "2847", color: .orange)
            }
        }
        .padding(24)
        .background(Color.white)
        .cornerRadius(24)
        .shadow(color: Color.black.opacity(0.04), radius: 15, x: 0, y: 10)
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 20)
        .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.3), value: appeared)
    }

    private var aiDetectionAccuracyCard: some View {
        VStack(spacing: 25) {
            HStack {
                Image(systemName: "bolt.fill")
                    .foregroundColor(.purple)
                Text("AI Detection Accuracy")
                    .font(.system(size: 18, weight: .bold))
                Spacer()
            }
            
            VStack(spacing: 12) {
                Text("96.8%")
                    .font(.system(size: 48, weight: .bold))
                    .foregroundColor(.purple)
                Text("Average confidence score")
                    .font(.system(size: 14))
                    .foregroundColor(.secondary)
            }
            
            VStack(alignment: .leading, spacing: 8) {
                Text("Excellent")
                    .font(.system(size: 12, weight: .bold))
                    .foregroundColor(.purple)
                
                Capsule()
                    .fill(Color.purple.opacity(0.1))
                    .frame(height: 10)
                    .overlay(
                        GeometryReader { geo in
                            Capsule()
                                .fill(LinearGradient(colors: [.purple, .purple.opacity(0.6)], startPoint: .leading, endPoint: .trailing))
                                .frame(width: geo.size.width * 0.968)
                        }
                    )
            }
            
            HStack(spacing: 15) {
                AccuracyTag(label: "98.5%", sublabel: "High Conf.", color: Color(hex: "00C853"))
                AccuracyTag(label: "95.2%", sublabel: "Medium", color: .blue)
                AccuracyTag(label: "92.1%", sublabel: "Low Conf.", color: .orange)
            }
        }
        .padding(24)
        .background(Color.white)
        .cornerRadius(24)
        .shadow(color: Color.black.opacity(0.04), radius: 15, x: 0, y: 10)
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 20)
        .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.4), value: appeared)
    }

    private var monthlyTrendComparisonCard: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                Image(systemName: "chart.line.uptrend.xyaxis")
                    .foregroundColor(.green)
                Text("Trend Comparison")
                    .font(.system(size: 18, weight: .bold))
            }
            
            Text(timeFilter == "Weekly" ? "Current Week vs Last Week" : (timeFilter == "Monthly" ? "Last 6 Months" : "Yearly Overview"))
                .font(.system(size: 14))
                .foregroundColor(.secondary)
            
            // Mock Chart
            ZStack {
                Path { path in
                    path.move(to: CGPoint(x: 0, y: timeFilter == "Weekly" ? 80 : 100))
                    path.addLine(to: CGPoint(x: 50, y: timeFilter == "Weekly" ? 60 : 80))
                    path.addLine(to: CGPoint(x: 100, y: timeFilter == "Weekly" ? 40 : 90))
                    path.addLine(to: CGPoint(x: 150, y: 60))
                    path.addLine(to: CGPoint(x: 200, y: 70))
                    path.addLine(to: CGPoint(x: 250, y: 40))
                }
                .stroke(Color(hex: "00C853"), lineWidth: 2)
                
                Path { path in
                    path.move(to: CGPoint(x: 0, y: 110))
                    path.addLine(to: CGPoint(x: 50, y: 95))
                    path.addLine(to: CGPoint(x: 100, y: 105))
                    path.addLine(to: CGPoint(x: 150, y: 85))
                    path.addLine(to: CGPoint(x: 200, y: timeFilter == "Weekly" ? 70 : 90))
                    path.addLine(to: CGPoint(x: 250, y: timeFilter == "Weekly" ? 50 : 110))
                }
                .stroke(Color.blue, lineWidth: 2)
            }
            .frame(height: 120)
            .padding(.top, 10)
            
            HStack {
                if timeFilter == "Weekly" {
                    Text("Mon").frame(maxWidth: .infinity)
                    Text("Tue").frame(maxWidth: .infinity)
                    Text("Wed").frame(maxWidth: .infinity)
                    Text("Thu").frame(maxWidth: .infinity)
                    Text("Fri").frame(maxWidth: .infinity)
                    Text("Sat").frame(maxWidth: .infinity)
                } else if timeFilter == "Monthly" {
                    Text("Sep").frame(maxWidth: .infinity)
                    Text("Oct").frame(maxWidth: .infinity)
                    Text("Nov").frame(maxWidth: .infinity)
                    Text("Dec").frame(maxWidth: .infinity)
                    Text("Jan").frame(maxWidth: .infinity)
                    Text("Feb").frame(maxWidth: .infinity)
                } else {
                    Text("2021").frame(maxWidth: .infinity)
                    Text("2022").frame(maxWidth: .infinity)
                    Text("2023").frame(maxWidth: .infinity)
                    Text("2024").frame(maxWidth: .infinity)
                    Text("2025").frame(maxWidth: .infinity)
                    Text("2026").frame(maxWidth: .infinity)
                }
            }
            .font(.system(size: 11))
            .foregroundColor(.secondary)
            
            HStack(spacing: 20) {
                LegendItem(label: "Registrations", color: Color(hex: "00C853"))
                LegendItem(label: "Verifications", color: .blue)
            }
            .padding(.top, 10)
        }
        .padding(24)
        .background(Color.white)
        .cornerRadius(24)
        .shadow(color: Color.black.opacity(0.04), radius: 15, x: 0, y: 10)
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 20)
        .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.5), value: appeared)
    }

    private var analyticsSummaryCard: some View {
        HStack(alignment: .top, spacing: 15) {
            Image(systemName: "chart.bar.doc.horizontal")
                .font(.title3)
                .foregroundColor(Color(hex: "00C853"))
            
            VStack(alignment: .leading, spacing: 4) {
                Text("Analytics Summary")
                    .font(.system(size: 15, weight: .bold))
                Text("All data is updated in real-time and\nreflects the current status of the BPA\nregistration system.")
                    .font(.system(size: 13))
                    .foregroundColor(.secondary)
                    .lineSpacing(2)
            }
        }
        .padding(24)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(hex: "00C853").opacity(0.05))
        .cornerRadius(24)
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 20)
        .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.6), value: appeared)
    }
    
    // MARK: - Helpers
    
    private func donutSegment(start: Double, end: Double, color: Color) -> some View {
        Circle()
            .trim(from: start, to: end)
            .stroke(color, lineWidth: 35)
            .rotationEffect(.degrees(-90))
    }
}

struct DistributionItem: View {
    let label: String
    let color: Color
    let value: String
    
    var body: some View {
        HStack(spacing: 8) {
            Circle()
                .fill(color)
                .frame(width: 8, height: 8)
            Text(label)
                .font(.system(size: 12))
                .foregroundColor(.secondary)
            Spacer()
            Text(value)
                .font(.system(size: 12, weight: .bold))
        }
    }
}

struct StatusRow: View {
    let label: String
    let value: String
    let total: String
    let color: Color
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(label)
                    .font(.system(size: 14, weight: .semibold))
                Spacer()
                Text(value)
                    .font(.system(size: 14, weight: .bold))
            }
            
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    Capsule()
                        .fill(Color.gray.opacity(0.1))
                    Capsule()
                        .fill(color)
                        .frame(width: geo.size.width * (Double(value) ?? 0) / (Double(total) ?? 1))
                }
            }
            .frame(height: 8)
            
            Text("\(String(format: "%.1f", (Double(value) ?? 0) / (Double(total) ?? 1) * 100))% of total")
                .font(.system(size: 11))
                .foregroundColor(.secondary)
        }
    }
}

struct AccuracyTag: View {
    let label: String
    let sublabel: String
    let color: Color
    
    var body: some View {
        VStack(spacing: 4) {
            Text(label)
                .font(.system(size: 14, weight: .bold))
                .foregroundColor(color)
            Text(sublabel)
                .font(.system(size: 10))
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .background(color.opacity(0.05))
        .cornerRadius(12)
    }
}

struct LegendItem: View {
    let label: String
    let color: Color
    
    var body: some View {
        HStack(spacing: 6) {
            Circle()
                .fill(color)
                .frame(width: 6, height: 6)
            Text(label)
                .font(.system(size: 11))
                .foregroundColor(.secondary)
        }
    }
}


// Custom Shape for solid Pie Chart Slices
struct PieSlice: Shape {
    var startAngle: Angle
    var endAngle: Angle
    
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let center = CGPoint(x: rect.midX, y: rect.midY)
        let radius = min(rect.width, rect.height) / 2
        
        path.move(to: center)
        path.addArc(center: center,
                    radius: radius,
                    startAngle: startAngle,
                    endAngle: endAngle,
                    clockwise: false)
        path.closeSubpath()
        
        return path
    }
}

#Preview {
    BPAAnalyticsView(path: .constant([]))
}
