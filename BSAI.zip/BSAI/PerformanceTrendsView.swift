import SwiftUI

struct PerformanceTrendsView: View {
    @Binding var path: [AppRoute]
    @State private var appeared = false
    
    let monthlyData = [
        PerformanceTrendItem(month: "Jan 2026", yield: "15.2 L/day", trend: "+5.3%", isPositive: true),
        PerformanceTrendItem(month: "Dec 2025", yield: "14.4 L/day", trend: "+2.1%", isPositive: true),
        PerformanceTrendItem(month: "Nov 2025", yield: "14.1 L/day avg", trend: "-1.2%", isPositive: false),
        PerformanceTrendItem(month: "Oct 2025", yield: "14.3 L/day avg", trend: "+3.8%", isPositive: true)
    ]
    
    var body: some View {
        VStack(spacing: 0) {
            navigationBar
            
            ScrollView(showsIndicators: false) {
                VStack(spacing: 25) {
                    overallPerformanceCard
                    monthlyTrendsSection
                    keyInsightsSection
                    
                    Spacer(minLength: 40)
                }
                .padding(.horizontal, 24)
            }
        }
        .background(Color(hex: "F8FBF9").ignoresSafeArea())
        .onAppear {
            appeared = true
        }
    }
    
    private var navigationBar: some View {
        HStack {
            Button(action: { 
                if !path.isEmpty {
                    _ = path.removeLast()
                }
            }) {
                Image(systemName: "arrow.left")
                    .font(.title3.bold())
                    .foregroundColor(.primary)
                    .padding(12)
                    .background(Color.white)
                    .clipShape(Circle())
                    .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
            }
            
            Text("Performance Trends")
                .font(.system(size: 20, weight: .bold))
                .padding(.leading, 10)
            
            Spacer()
        }
        .padding()
        .background(Color(.systemBackground))
    }
    
    private var overallPerformanceCard: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack(spacing: 15) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.purple.opacity(0.1))
                        .frame(width: 44, height: 44)
                    Image(systemName: "waveform.path")
                        .foregroundColor(.purple)
                }
                
                VStack(alignment: .leading, spacing: 2) {
                    Text("Overall Performance")
                        .font(.headline)
                    Text("Last 4 months")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            VStack(spacing: 8) {
                Text("10.2 L/day")
                    .font(.system(size: 34, weight: .black))
                    .foregroundColor(Color(hex: "4A148C"))
                
                HStack(spacing: 4) {
                    Image(systemName: "chart.line.uptrend.xyaxis")
                    Text("+5.3% from last month")
                }
                .font(.subheadline.bold())
                .foregroundColor(.green)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 30)
            .background(Color.purple.opacity(0.03))
            .cornerRadius(20)
            .overlay(
                RoundedRectangle(cornerRadius: 20)
                    .stroke(Color.purple.opacity(0.1), lineWidth: 1)
            )
        }
        .padding(24)
        .background(Color.white)
        .cornerRadius(30)
        .shadow(color: Color.black.opacity(0.04), radius: 15, x: 0, y: 10)
        .padding(.top, 20)
        .opacity(appeared ? 1 : 0)
        .scaleEffect(appeared ? 1 : 0.95)
        .animation(.spring(response: 0.6, dampingFraction: 0.75).delay(0.1), value: appeared)
    }
    
    private var monthlyTrendsSection: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("Monthly Trends")
                .font(.system(size: 18, weight: .bold))
            
            VStack(spacing: 12) {
                ForEach(Array(monthlyData.enumerated()), id: \.offset) { index, item in
                    PerformanceTrendRow(item: item)
                        .opacity(appeared ? 1 : 0)
                        .offset(y: appeared ? 0 : 20)
                        .animation(.spring(response: 0.5, dampingFraction: 0.8).delay(Double(index) * 0.1 + 0.3), value: appeared)
                }
            }
        }
    }
    
    private var keyInsightsSection: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("Key Insights")
                .font(.system(size: 18, weight: .bold))
            
            HStack(alignment: .top, spacing: 15) {
                Image(systemName: "chart.line.uptrend.xyaxis")
                    .foregroundColor(.green)
                    .font(.title3)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text("Positive Trend")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(.green)
                    Text("Production increasing steadily over 3 months")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .lineSpacing(4)
                }
            }
            .padding(20)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.green.opacity(0.05))
            .cornerRadius(20)
        }
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 20)
        .animation(.easeOut(duration: 0.5).delay(0.7), value: appeared)
    }
}

struct PerformanceTrendItem {
    let month: String
    let yield: String
    let trend: String
    let isPositive: Bool
}

struct PerformanceTrendRow: View {
    let item: PerformanceTrendItem
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(item.month)
                    .font(.system(size: 16, weight: .bold))
                Text(item.yield)
                    .font(.system(size: 14))
                    .foregroundColor(.secondary)
                Text("avg")
                    .font(.system(size: 12))
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            HStack(spacing: 6) {
                Image(systemName: item.isPositive ? "chart.line.uptrend.xyaxis" : "chart.line.downtrend.xyaxis")
                Text(item.trend)
            }
            .font(.system(size: 14, weight: .bold))
            .foregroundColor(item.isPositive ? .green : .orange)
        }
        .padding(16)
        .background(Color.white)
        .cornerRadius(20)
        .shadow(color: Color.black.opacity(0.02), radius: 5, x: 0, y: 2)
    }
}

#Preview {
    PerformanceTrendsView(path: .constant([]))
}
