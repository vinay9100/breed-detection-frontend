import SwiftUI

struct ScanHistoryView: View {
    @Binding var path: [AppRoute]
    @State private var appeared = false
    
    let scans = [
        ScanItem(breed: "Holstein Friesian", date: "Feb 9, 2026", confidence: "96%", yield: "18.5 L/day"),
        ScanItem(breed: "Murrah Buffalo", date: "Feb 7, 2026", confidence: "94%", yield: "12.3 L/day"),
        ScanItem(breed: "Jersey Cow", date: "Feb 5, 2026", confidence: "98%", yield: "15.2 L/day"),
        ScanItem(breed: "Gir Cow", date: "Feb 3, 2026", confidence: "92%", yield: "10.8 L/day")
    ]
    
    var body: some View {
        VStack(spacing: 0) {
            navigationBar
            
            ScrollView(showsIndicators: false) {
                VStack(spacing: 25) {
                    headerSection
                    historyList
                    footerNote
                    
                    Spacer(minLength: 40)
                }
                .padding(.horizontal, 24)
            }
        }
        .background(Color(hex: "F8FBF9").ignoresSafeArea())
        .onAppear {
            appeared = true
        }
    }
    
    private var navigationBar: some View {
        HStack {
            Button(action: { 
                if !path.isEmpty {
                    _ = path.removeLast()
                }
            }) {
                Image(systemName: "arrow.left")
                    .font(.title3.bold())
                    .foregroundColor(.primary)
                    .padding(12)
                    .background(Color.white)
                    .clipShape(Circle())
                    .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
            }
            
            Text("Scan History")
                .font(.system(size: 20, weight: .bold))
                .padding(.leading, 10)
            
            Spacer()
        }
        .padding()
        .background(Color(.systemBackground))
    }
    
    private var headerSection: some View {
        HStack(alignment: .bottom) {
            VStack(alignment: .leading, spacing: 4) {
                Text("Recent Scans")
                    .font(.system(size: 20, weight: .bold))
                Text("4 total scans")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            Button("View Analytics") {
                path.append(.analyticsHub)
            }
            .font(.system(size: 14, weight: .bold))
            .foregroundColor(.green)
        }
        .padding(.top, 20)
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 10)
        .animation(.easeOut(duration: 0.5), value: appeared)
    }
    
    private var historyList: some View {
        VStack(spacing: 16) {
            ForEach(Array(scans.enumerated()), id: \.offset) { index, scan in
                Button(action: {
                    withAnimation(.spring()) {
                        path.append(.detectionResult)
                    }
                }) {
                    ScanHistoryCard(scan: scan)
                }
                .buttonStyle(PlainButtonStyle())
                .opacity(appeared ? 1 : 0)
                .offset(y: appeared ? 0 : 20)
                .animation(.spring(response: 0.5, dampingFraction: 0.8).delay(Double(index) * 0.1 + 0.2), value: appeared)
            }
        }
    }
    
    private var footerNote: some View {
        HStack(spacing: 12) {
            Text("📊")
                .font(.system(size: 18))
            Text("Tap any scan to view detailed results and insights")
                .font(.system(size: 13, weight: .medium))
                .foregroundColor(.blue)
        }
        .padding(16)
        .frame(maxWidth: .infinity)
        .background(Color.blue.opacity(0.05))
        .cornerRadius(15)
        .overlay(
            RoundedRectangle(cornerRadius: 15)
                .stroke(Color.blue.opacity(0.1), lineWidth: 1)
        )
        .opacity(appeared ? 1 : 0)
        .animation(.easeOut(duration: 0.5).delay(0.6), value: appeared)
    }
}

struct ScanItem {
    let breed: String
    let date: String
    let confidence: String
    let yield: String
}

struct ScanHistoryCard: View {
    let scan: ScanItem
    
    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(scan.breed)
                        .font(.system(size: 18, weight: .bold))
                    HStack(spacing: 6) {
                        Image(systemName: "calendar")
                            .font(.caption)
                        Text(scan.date)
                            .font(.system(size: 13))
                    }
                    .foregroundColor(.secondary)
                }
                Spacer()
                Image(systemName: "eye")
                    .foregroundColor(.secondary)
            }
            
            HStack(spacing: 40) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Confidence")
                        .font(.system(size: 12))
                        .foregroundColor(.secondary)
                    Text(scan.confidence)
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(.green)
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    HStack(spacing: 4) {
                        Image(systemName: "chart.line.uptrend.xyaxis")
                            .font(.caption)
                            .foregroundColor(.blue)
                        Text("Yield")
                            .font(.system(size: 12))
                            .foregroundColor(.secondary)
                    }
                    Text(scan.yield)
                        .font(.system(size: 16, weight: .bold))
                }
            }
        }
        .padding(24)
        .background(Color.white)
        .cornerRadius(25)
        .shadow(color: Color.black.opacity(0.03), radius: 10, x: 0, y: 5)
    }
}

#Preview {
    ScanHistoryView(path: .constant([]))
}
